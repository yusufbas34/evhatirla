class AppConstants {
  AppConstants._();

  static const String appName = 'EvHatırla';
  static const String appVersion = '1.0.0';

  // Firestore koleksiyon isimleri
  static const String usersCollection = 'users';
  static const String householdsCollection = 'households';
  static const String itemsSubcollection = 'items';
  static const String historySubcollection = 'history';
  static const String notificationsSubcollection = 'notifications';
  static const String categoriesCollection = 'categories';
  static const String marketPricesCollection = 'marketPrices';

  // Feature flags
  static const bool marketFeatureEnabled = false; // v2'de açılacak
  static const bool darkModeEnabled = false; // v1.1'de açılacak

  // Limitler
  static const int maxHouseholdMembers = 8;
  static const int defaultReminderHour = 9;
  static const Duration inviteCodeExpiry = Duration(hours: 48);

  // Sessiz saatler varsayılan
  static const int defaultQuietStartHour = 22;
  static const int defaultQuietEndHour = 8;
}

/// İhtiyaç stok durumu
enum StokDurumu {
  var_('var', 'Var'),
  azaldi('azaldi', 'Azaldı'),
  bitti('bitti', 'Bitti');

  final String key;
  final String label;
  const StokDurumu(this.key, this.label);

  static StokDurumu fromKey(String key) =>
      StokDurumu.values.firstWhere((e) => e.key == key, orElse: () => StokDurumu.var_);
}

/// Bildirim aksiyonları
enum BildirimAksiyon {
  hatirlatma('hatirlatma'),
  tamamlandi('tamamlandi'),
  ertelendi('ertelendi'),
  eklendi('eklendi'),
  duzenlendi('duzenlendi');

  final String key;
  const BildirimAksiyon(this.key);
}

/// Aile üyesi rolleri
enum UyeRolu {
  owner('owner', 'Kurucu'),
  admin('admin', 'Yönetici'),
  member('member', 'Üye');

  final String key;
  final String label;
  const UyeRolu(this.key, this.label);

  static UyeRolu fromKey(String key) =>
      UyeRolu.values.firstWhere((e) => e.key == key, orElse: () => UyeRolu.member);
}
