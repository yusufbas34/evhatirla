/// Yeni ev oluşturulduğunda otomatik atanacak varsayılan kategoriler ve ihtiyaçlar
library;

class DefaultCategory {
  final String id;
  final String ad;
  final String ikon;
  final int renkIndex;
  final int sira;

  const DefaultCategory({
    required this.id,
    required this.ad,
    required this.ikon,
    required this.renkIndex,
    required this.sira,
  });
}

class DefaultItem {
  final String ad;
  final String ikon;
  final String categoryId;
  final int hatirlatmaPeriyodu; // gün
  final bool aktif; // varsayılan aktif olanlar
  final List<String> marketTags; // ileride market entegrasyonu için

  const DefaultItem({
    required this.ad,
    required this.ikon,
    required this.categoryId,
    required this.hatirlatmaPeriyodu,
    this.aktif = true,
    this.marketTags = const [],
  });
}

class DefaultData {
  DefaultData._();

  static const List<DefaultCategory> kategoriler = [
    DefaultCategory(id: 'mutfak', ad: 'Mutfak', ikon: '🍳', renkIndex: 0, sira: 1),
    DefaultCategory(id: 'banyo', ad: 'Banyo', ikon: '🛁', renkIndex: 1, sira: 2),
    DefaultCategory(id: 'temizlik', ad: 'Temizlik', ikon: '🧽', renkIndex: 2, sira: 3),
    DefaultCategory(id: 'cocuk', ad: 'Çocuk', ikon: '👶', renkIndex: 3, sira: 4),
    DefaultCategory(id: 'kisisel', ad: 'Kişisel Bakım', ikon: '🪥', renkIndex: 4, sira: 5),
    DefaultCategory(id: 'ev', ad: 'Ev Gereçleri', ikon: '🏠', renkIndex: 5, sira: 6),
    DefaultCategory(id: 'gida', ad: 'Gıda', ikon: '🛒', renkIndex: 6, sira: 7),
    DefaultCategory(id: 'diger', ad: 'Diğer', ikon: '📦', renkIndex: 7, sira: 8),
  ];

  /// Yeni ev oluşturulduğunda otomatik atanan temel ihtiyaçlar
  static const List<DefaultItem> temelIhtiyaclar = [
    // Mutfak
    DefaultItem(ad: 'Yumurta', ikon: '🥚', categoryId: 'mutfak', hatirlatmaPeriyodu: 7, marketTags: ['yumurta', 'kahvaltilik']),
    DefaultItem(ad: 'Süt', ikon: '🥛', categoryId: 'mutfak', hatirlatmaPeriyodu: 3, marketTags: ['sut', 'kahvaltilik']),
    DefaultItem(ad: 'Ekmek', ikon: '🍞', categoryId: 'mutfak', hatirlatmaPeriyodu: 1, marketTags: ['ekmek']),
    DefaultItem(ad: 'Peynir', ikon: '🧀', categoryId: 'mutfak', hatirlatmaPeriyodu: 10, marketTags: ['peynir', 'kahvaltilik']),
    DefaultItem(ad: 'Çay', ikon: '🍵', categoryId: 'mutfak', hatirlatmaPeriyodu: 30, marketTags: ['cay']),
    DefaultItem(ad: 'Şeker', ikon: '🍬', categoryId: 'mutfak', hatirlatmaPeriyodu: 30, marketTags: ['seker']),
    DefaultItem(ad: 'Tuz', ikon: '🧂', categoryId: 'mutfak', hatirlatmaPeriyodu: 60, marketTags: ['tuz']),
    DefaultItem(ad: 'Yağ', ikon: '🫒', categoryId: 'mutfak', hatirlatmaPeriyodu: 21, marketTags: ['yag', 'zeytinyagi']),

    // Banyo
    DefaultItem(ad: 'Şampuan', ikon: '🧴', categoryId: 'banyo', hatirlatmaPeriyodu: 30, marketTags: ['sampuan']),
    DefaultItem(ad: 'Duş Jeli', ikon: '🧴', categoryId: 'banyo', hatirlatmaPeriyodu: 30, marketTags: ['dus_jeli']),
    DefaultItem(ad: 'Tuvalet Kağıdı', ikon: '🧻', categoryId: 'banyo', hatirlatmaPeriyodu: 14, marketTags: ['tuvalet_kagidi']),
    DefaultItem(ad: 'Sabun', ikon: '🧼', categoryId: 'banyo', hatirlatmaPeriyodu: 30, marketTags: ['sabun']),

    // Temizlik
    DefaultItem(ad: 'Çamaşır Deterjanı', ikon: '🧺', categoryId: 'temizlik', hatirlatmaPeriyodu: 21, marketTags: ['camasir_deterjani']),
    DefaultItem(ad: 'Bulaşık Deterjanı', ikon: '🍽️', categoryId: 'temizlik', hatirlatmaPeriyodu: 14, marketTags: ['bulasik_deterjani']),
    DefaultItem(ad: 'Yumuşatıcı', ikon: '🌸', categoryId: 'temizlik', hatirlatmaPeriyodu: 30, marketTags: ['yumusatici']),
    DefaultItem(ad: 'Çamaşır Suyu', ikon: '💧', categoryId: 'temizlik', hatirlatmaPeriyodu: 45, marketTags: ['camasir_suyu']),
    DefaultItem(ad: 'Yüzey Temizleyici', ikon: '🧴', categoryId: 'temizlik', hatirlatmaPeriyodu: 30, marketTags: ['yuzey_temizleyici']),

    // Kişisel bakım
    DefaultItem(ad: 'Diş Macunu', ikon: '🪥', categoryId: 'kisisel', hatirlatmaPeriyodu: 30, marketTags: ['dis_macunu']),

    // Ev
    DefaultItem(ad: 'Çöp Poşeti', ikon: '🗑️', categoryId: 'ev', hatirlatmaPeriyodu: 30, marketTags: ['cop_poseti']),

    // Pasif olanlar — kullanıcı isterse aktif eder (örnek)
    DefaultItem(ad: 'Bebek Bezi', ikon: '👶', categoryId: 'cocuk', hatirlatmaPeriyodu: 7, aktif: false, marketTags: ['bebek_bezi']),
    DefaultItem(ad: 'Mama', ikon: '🍼', categoryId: 'cocuk', hatirlatmaPeriyodu: 14, aktif: false, marketTags: ['mama']),
    DefaultItem(ad: 'Kahve', ikon: '☕', categoryId: 'mutfak', hatirlatmaPeriyodu: 21, aktif: false, marketTags: ['kahve']),
  ];
}
