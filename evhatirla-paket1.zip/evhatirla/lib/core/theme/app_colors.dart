import 'package:flutter/material.dart';

/// EvHatırla renk paleti
/// Canlı, sıcak, aile dostu bir palet
class AppColors {
  AppColors._();

  // Ana renkler — Sıcak coral/turuncu tema
  static const Color primary = Color(0xFFFF6B47); // Sıcak mercan
  static const Color primaryLight = Color(0xFFFF8A6E);
  static const Color primaryDark = Color(0xFFE54A28);

  // İkincil — yumuşak teal
  static const Color secondary = Color(0xFF1D9E75);
  static const Color secondaryLight = Color(0xFF5DCAA5);

  // Aksiyon renkleri
  static const Color success = Color(0xFF22C55E);
  static const Color warning = Color(0xFFF59E0B);
  static const Color danger = Color(0xFFEF4444);
  static const Color info = Color(0xFF3B82F6);

  // Nötr tonlar
  static const Color background = Color(0xFFFAF9F6);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceMuted = Color(0xFFF4F2ED);
  static const Color border = Color(0xFFE5E3DD);

  // Metin
  static const Color textPrimary = Color(0xFF1F1E1B);
  static const Color textSecondary = Color(0xFF6B6863);
  static const Color textTertiary = Color(0xFFA09D96);
  static const Color textOnPrimary = Color(0xFFFFFFFF);

  // İhtiyaç durum renkleri
  static const Color stokVar = Color(0xFF22C55E); // yeşil
  static const Color stokAzaldi = Color(0xFFF59E0B); // turuncu
  static const Color stokBitti = Color(0xFFEF4444); // kırmızı

  // Kategori renkleri (8 farklı kategori için)
  static const List<Color> categoryColors = [
    Color(0xFFFF6B47), // mutfak — coral
    Color(0xFF3B82F6), // banyo — mavi
    Color(0xFF22C55E), // temizlik — yeşil
    Color(0xFFA855F7), // çocuk — mor
    Color(0xFFEC4899), // kişisel — pembe
    Color(0xFFF59E0B), // ev gereçleri — amber
    Color(0xFF14B8A6), // gıda — teal
    Color(0xFF6B7280), // diğer — gri
  ];

  // Dark mode (ileride genişletilecek)
  static const Color darkBackground = Color(0xFF1A1917);
  static const Color darkSurface = Color(0xFF26241F);
  static const Color darkBorder = Color(0xFF3A3833);
}
