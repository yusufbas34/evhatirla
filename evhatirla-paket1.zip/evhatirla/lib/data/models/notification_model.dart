import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/constants/app_constants.dart';

class NotificationModel {
  final String id;
  final String? itemId;
  final String? itemAd;
  final BildirimAksiyon tip;
  final String mesaj;
  final List<String> hedefUidler;
  final List<String> okuyanlar;
  final String? aktorUid;
  final String? aktorAd;
  final DateTime zaman;

  const NotificationModel({
    required this.id,
    this.itemId,
    this.itemAd,
    required this.tip,
    required this.mesaj,
    required this.hedefUidler,
    this.okuyanlar = const [],
    this.aktorUid,
    this.aktorAd,
    required this.zaman,
  });

  factory NotificationModel.fromMap(Map<String, dynamic> map, String id) {
    return NotificationModel(
      id: id,
      itemId: map['itemId'] as String?,
      itemAd: map['itemAd'] as String?,
      tip: BildirimAksiyon.values.firstWhere(
        (e) => e.key == (map['tip'] as String?),
        orElse: () => BildirimAksiyon.hatirlatma,
      ),
      mesaj: (map['mesaj'] as String?) ?? '',
      hedefUidler: List<String>.from((map['hedefUidler'] as List?) ?? []),
      okuyanlar: List<String>.from((map['okuyanlar'] as List?) ?? []),
      aktorUid: map['aktorUid'] as String?,
      aktorAd: map['aktorAd'] as String?,
      zaman: (map['zaman'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        'itemId': itemId,
        'itemAd': itemAd,
        'tip': tip.key,
        'mesaj': mesaj,
        'hedefUidler': hedefUidler,
        'okuyanlar': okuyanlar,
        'aktorUid': aktorUid,
        'aktorAd': aktorAd,
        'zaman': Timestamp.fromDate(zaman),
      };

  bool okunduMu(String uid) => okuyanlar.contains(uid);
}
