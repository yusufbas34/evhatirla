import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String ad;
  final String email;
  final String? fotoUrl;
  final String? activeHouseholdId;
  final String? fcmToken;
  final int sessizSaatBaslangic; // 0-23
  final int sessizSaatBitis;
  final DateTime createdAt;

  const UserModel({
    required this.uid,
    required this.ad,
    required this.email,
    this.fotoUrl,
    this.activeHouseholdId,
    this.fcmToken,
    this.sessizSaatBaslangic = 22,
    this.sessizSaatBitis = 8,
    required this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map, String uid) {
    return UserModel(
      uid: uid,
      ad: (map['ad'] as String?) ?? '',
      email: (map['email'] as String?) ?? '',
      fotoUrl: map['fotoUrl'] as String?,
      activeHouseholdId: map['activeHouseholdId'] as String?,
      fcmToken: map['fcmToken'] as String?,
      sessizSaatBaslangic: (map['sessizSaatBaslangic'] as int?) ?? 22,
      sessizSaatBitis: (map['sessizSaatBitis'] as int?) ?? 8,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        'ad': ad,
        'email': email,
        'fotoUrl': fotoUrl,
        'activeHouseholdId': activeHouseholdId,
        'fcmToken': fcmToken,
        'sessizSaatBaslangic': sessizSaatBaslangic,
        'sessizSaatBitis': sessizSaatBitis,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  UserModel copyWith({
    String? ad,
    String? fotoUrl,
    String? activeHouseholdId,
    String? fcmToken,
    int? sessizSaatBaslangic,
    int? sessizSaatBitis,
  }) =>
      UserModel(
        uid: uid,
        ad: ad ?? this.ad,
        email: email,
        fotoUrl: fotoUrl ?? this.fotoUrl,
        activeHouseholdId: activeHouseholdId ?? this.activeHouseholdId,
        fcmToken: fcmToken ?? this.fcmToken,
        sessizSaatBaslangic: sessizSaatBaslangic ?? this.sessizSaatBaslangic,
        sessizSaatBitis: sessizSaatBitis ?? this.sessizSaatBitis,
        createdAt: createdAt,
      );
}
